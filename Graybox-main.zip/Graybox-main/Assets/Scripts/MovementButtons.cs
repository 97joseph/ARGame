
public enum MovementButtons
{
    None        = 0,
    Left        = 1 << 1,
    Right       = 1 << 2,
    Forward     = 1 << 3,
    Back        = 1 << 4,
    Jump        = 1 << 5
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Graybox.Tools
{
    public abstract class gb_MeshShape
    {
        public abstract GameObject Generate();
    }
}


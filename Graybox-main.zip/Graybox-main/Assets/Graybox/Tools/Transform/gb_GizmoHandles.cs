using UnityEngine;

namespace Graybox.Tools
{
    public class gb_GizmoHandles : gb_ToolHandle
    {
        public Vector3 Axis;
    }
}


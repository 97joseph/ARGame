using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Graybox
{
    public enum gb_TransformDirection
    {
        None,
        Forward,
        Right,
        Up
    }
}

